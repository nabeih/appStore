<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'نظام إدارة المتجر'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/catalog/color-dot.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/pages/auth/session.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/mobile-documents.css')); ?>">
</head>

<body class="laravel-admin">

    <div id="appScreen">


        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main class="main-content">

            <?php echo $__env->make('partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

        </main>
    </div>

    <div class="toast-container" id="toastContainer"></div>

    <script src="<?php echo e(asset('assets/admin/js/pages/auth/session.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/admin/js/layout.js')); ?>" defer></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/layouts/app.blade.php ENDPATH**/ ?>