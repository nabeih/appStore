<?php if (! $__env->hasRenderedOnce('b4280289-975e-4556-b2df-fa97765aea3b')): $__env->markAsRenderedOnce('b4280289-975e-4556-b2df-fa97765aea3b'); ?>
    <?php $__env->startPush('styles'); ?><link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/catalog/color-images.css')); ?>"><?php $__env->stopPush(); ?>
    <?php $__env->startPush('scripts'); ?><script src="<?php echo e(asset('assets/admin/js/pages/catalog/color-images.js')); ?>" defer></script><?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/components/catalog/color-image-assets.blade.php ENDPATH**/ ?>