<?php $__env->startSection('title', 'فواتير الشراء'); ?>
<?php $__env->startPush('styles'); ?><link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/pages/purchases/invoices.css')); ?>"><?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="screen active trade-page">
    <header class="trade-heading"><div><h1 class="section-title"><i class="fas fa-file-invoice text-primary" aria-hidden="true"></i> فواتير الشراء</h1><p class="section-subtitle">المشتريات ودفعات الموردين.</p></div><a class="btn btn-primary" href="<?php echo e(route('purchases.invoices.create')); ?>">+ فاتورة جديدة</a></header>
    <form method="get" class="card document-search-card">
        <div class="document-search-bar"><label>البحث<input name="q" maxlength="100" value="<?php echo e($filters['q'] ?? ''); ?>" placeholder="المورد أو رقم الفاتورة"></label><button class="btn btn-primary" type="submit">بحث</button></div>
        <details class="document-filters" <?php if(array_filter(\Illuminate\Support\Arr::except($filters,'q'))): ?> open <?php endif; ?>>
            <summary><span><i class="fas fa-sliders-h" aria-hidden="true"></i> خيارات التصفية</span><small>الحالة، الفرع، التاريخ</small></summary>
            <div class="document-filter-grid">
                <label>الحالة<select name="status"><option value="">كل الحالات</option><?php $__currentLoopData = ['draft'=>'مسودة','approved'=>'معتمدة','cancelled'=>'مسودة ملغاة']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if(($filters['status'] ?? '')===$value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                <label>الفرع<select name="branch_id"><option value="">كل الفروع</option><?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($branch->id); ?>" <?php if(($filters['branch_id'] ?? '')==$branch->id): echo 'selected'; endif; ?>><?php echo e($branch->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                <?php if(isset($filters['supplier_id'])): ?><input type="hidden" name="supplier_id" value="<?php echo e($filters['supplier_id']); ?>"><?php endif; ?>
                <label>من تاريخ<input type="date" name="from" value="<?php echo e($filters['from'] ?? ''); ?>"></label><label>إلى تاريخ<input type="date" name="to" value="<?php echo e($filters['to'] ?? ''); ?>"></label>
                <div class="document-filter-actions"><button class="btn btn-primary" type="submit">تطبيق</button><a class="btn btn-outline" href="<?php echo e(route('purchases.invoices.index')); ?>">مسح</a></div>
            </div>
        </details>
    </form>
    <section class="card document-record-list"><div class="table-responsive"><table class="mobile-records" role="table" aria-label="فواتير الشراء"><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>المورد / الفرع</th><th>الحالة</th><th>القطع</th><th>الإجمالي ₪</th><th>المدفوع ₪</th><th>المتبقي ₪</th><th></th></tr></thead><tbody>
    <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td class="record-primary" data-label="الفاتورة"><a href="<?php echo e(route('purchases.invoices.show',$entry)); ?>"><?php echo e($entry->number); ?></a><small><?php echo e($entry->supplier_invoice_number); ?></small></td>
            <td data-label="التاريخ"><?php echo e($entry->invoice_date->format('Y/m/d')); ?></td>
            <td class="record-wide" data-label="المورد / الفرع"><?php echo e($entry->supplier_name); ?><small><?php echo e($entry->branch_name); ?></small></td>
            <td class="record-status"><span class="trade-status <?php echo e($entry->status); ?>"><?php echo e(['draft'=>'مسودة','approved'=>'معتمدة','cancelled'=>'ملغاة'][$entry->status]); ?></span></td>
            <td data-label="القطع"><?php echo e($entry->total_quantity); ?></td>
            <td class="record-amount" data-label="الإجمالي ₪"><?php echo e($entry->total_amount); ?></td>
            <td data-label="المدفوع ₪"><?php echo e($entry->status==='approved' ? $entry->paid_amount : '—'); ?></td>
            <td data-label="المتبقي ₪"><?php echo e($entry->status==='approved' ? $entry->remaining_amount : '—'); ?></td>
            <td class="record-action"><a class="btn btn-outline btn-sm" href="<?php echo e(route('purchases.invoices.show',$entry)); ?>">عرض الفاتورة</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr class="record-empty"><td colspan="9" class="trade-empty"><strong>لا توجد فواتير مطابقة</strong><p>ابدأ بإضافة فاتورة شراء.</p><a class="btn btn-primary" href="<?php echo e(route('purchases.invoices.create')); ?>">فاتورة جديدة</a></td></tr>
    <?php endif; ?>
    </tbody></table></div><?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $entries]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entries)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?></section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/purchases/invoices/index.blade.php ENDPATH**/ ?>