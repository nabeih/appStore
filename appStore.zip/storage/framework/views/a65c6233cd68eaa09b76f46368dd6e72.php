<div class="attribute-pagination">
    <span><?php echo e($entries->total()); ?> نتيجة — صفحة <?php echo e($entries->currentPage()); ?> من <?php echo e($entries->lastPage()); ?></span>
    <?php if($entries->hasPages()): ?>
        <nav aria-label="صفحات النتائج">
            <?php if($entries->onFirstPage()): ?><span class="attribute-page disabled">السابق</span><?php else: ?><a class="attribute-page" href="<?php echo e($entries->previousPageUrl()); ?>" data-attribute-nav>السابق</a><?php endif; ?>
            <?php for($page = max(1, $entries->currentPage() - 2); $page <= min($entries->lastPage(), $entries->currentPage() + 2); $page++): ?>
                <a class="attribute-page <?php echo e($page === $entries->currentPage() ? 'active' : ''); ?>" href="<?php echo e($entries->url($page)); ?>" data-attribute-nav <?php if($page === $entries->currentPage()): ?> aria-current="page" <?php endif; ?>><?php echo e($page); ?></a>
            <?php endfor; ?>
            <?php if($entries->hasMorePages()): ?><a class="attribute-page" href="<?php echo e($entries->nextPageUrl()); ?>" data-attribute-nav>التالي</a><?php else: ?><span class="attribute-page disabled">التالي</span><?php endif; ?>
        </nav>
    <?php endif; ?>
</div><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/catalog/attributes/partials/pagination.blade.php ENDPATH**/ ?>