<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/pages/inventory/opening-stock.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="application/json" id="opening-stock-config"><?php echo json_encode([
        'imageResolveUrl' => route('inventory.opening-stock.images.resolve'),
        'optionsUrl' => route('inventory.opening-stock.options'),
        'optionsStoreUrl' => route('inventory.opening-stock.options.store'),
        'productsUrl' => route('inventory.opening-stock.products'),
        'previewUrl' => route('inventory.opening-stock.preview'),
        'saveUrl' => route('inventory.opening-stock.store'),
        'csrf' => csrf_token(),
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
    <script src="<?php echo e(asset('assets/admin/js/pages/inventory/opening-stock.js')); ?>" defer></script>
<?php $__env->stopPush(); ?><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/inventory/opening-stock/partials/scripts.blade.php ENDPATH**/ ?>