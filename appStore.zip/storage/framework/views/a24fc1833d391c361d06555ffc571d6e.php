<form method="post" action="<?php echo e(route('catalog.attributes.colors.store')); ?>" data-attribute-form="colors" class="attribute-form">
    <?php echo csrf_field(); ?>
    <h2>إضافة لون</h2>
    <div class="attribute-errors" data-form-errors role="alert" tabindex="-1" hidden></div>
    <fieldset>
        <?php if (isset($component)) { $__componentOriginala84b9a15176309deae827ab63ec9aff1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala84b9a15176309deae827ab63ec9aff1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.catalog.color-editor','data' => ['id' => 'create-color','palette' => $palette,'nameValue' => old('name', ''),'hexValue' => old('hex_code', '')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('catalog.color-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'create-color','palette' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($palette),'name-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', '')),'hex-value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('hex_code', ''))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala84b9a15176309deae827ab63ec9aff1)): ?>
<?php $attributes = $__attributesOriginala84b9a15176309deae827ab63ec9aff1; ?>
<?php unset($__attributesOriginala84b9a15176309deae827ab63ec9aff1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala84b9a15176309deae827ab63ec9aff1)): ?>
<?php $component = $__componentOriginala84b9a15176309deae827ab63ec9aff1; ?>
<?php unset($__componentOriginala84b9a15176309deae827ab63ec9aff1); ?>
<?php endif; ?>
        <details class="attribute-optional"><summary>رمز مختصر (اختياري)</summary><label for="color-code">رمز اللون</label><input id="color-code" name="code" dir="ltr" maxlength="20" value="<?php echo e(old('code')); ?>" placeholder="مثال: BLK — يجهّز تلقائيًا عند تركه فارغًا"></details>
        <button type="submit" class="btn btn-primary attribute-submit">إضافة اللون</button>
    </fieldset>
</form><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/catalog/attributes/partials/color-form.blade.php ENDPATH**/ ?>