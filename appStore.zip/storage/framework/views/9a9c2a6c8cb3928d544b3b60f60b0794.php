<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['hex' => null, 'label' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['hex' => null, 'label' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php ($validHex = is_string($hex) && preg_match('/^#[0-9a-f]{6}$/i', $hex) ? strtoupper($hex) : null); ?>
<span <?php echo e($attributes->class(['catalog-color-dot', 'catalog-color-unknown' => !$validHex])); ?> <?php if($validHex): ?> style="background-color:<?php echo e($validHex); ?>" <?php endif; ?> title="<?php echo e($label); ?>" aria-hidden="true"></span><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/components/catalog/color-dot.blade.php ENDPATH**/ ?>