<?php $__env->startSection('title', 'التصنيفات والسمات'); ?>
<?php $__env->startPush('styles'); ?><link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/pages/catalog/attributes.css')); ?>"><?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div id="catalog-attributes" class="screen active" data-active-tab="<?php echo e($tab); ?>">
    <h1 class="section-title"><i class="fas fa-tags text-primary"></i> التصنيفات والسمات</h1>
    <p class="section-subtitle">نظّم أصنافك وألوانها ومقاساتها من مكان واحد.</p>
    <?php if(session('success')): ?><p class="attribute-success" role="status"><?php echo e(session('success')); ?></p><?php endif; ?>
    <?php if($errors->any()): ?><div class="attribute-errors" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <nav class="attribute-tabs" aria-label="أقسام التصنيفات والسمات">
        <?php $__currentLoopData = ['categories' => ['التصنيفات', 'fa-tags'], 'colors' => ['الألوان', 'fa-palette'], 'sizes' => ['المقاسات', 'fa-ruler']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => [$label, $icon]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('catalog.attributes.index', ['tab' => $key])); ?>" data-attribute-nav class="attribute-tab <?php echo e($tab === $key ? 'active' : ''); ?>" <?php if($tab === $key): ?> aria-current="page" <?php endif; ?>><i class="fas <?php echo e($icon); ?>"></i><span><?php echo e($label); ?></span><span class="attribute-count"><?php echo e($counts[$key]); ?></span></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
    <div class="attribute-layout">
        <aside class="card attribute-form-card">
            <?php echo $__env->make('catalog.attributes.partials.'.match($tab) { 'colors' => 'color', 'sizes' => 'size', default => 'category' }.'-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </aside>
        <section class="card attribute-list-card" aria-label="القائمة الحالية">
            <header class="attribute-list-header"><h2><?php echo e(match($tab) { 'colors' => 'الألوان المتاحة', 'sizes' => 'المقاسات المتاحة', default => 'التصنيفات المتاحة' }); ?></h2>
                <form method="get" action="<?php echo e(route('catalog.attributes.index')); ?>" id="attribute-search-form"><input type="hidden" name="tab" value="<?php echo e($tab); ?>"><input name="q" id="attribute-search" type="search" maxlength="100" value="<?php echo e($search); ?>" placeholder="بحث بالاسم<?php echo e($tab !== 'categories' ? ' أو الرمز' : ''); ?>..." aria-label="بحث في القائمة"><button class="btn btn-outline btn-sm" type="submit">بحث</button></form>
            </header>
            <div class="table-responsive"><table class="attribute-table"><thead><tr>
                <th><?php echo e($tab === 'colors' ? 'اللون' : 'الاسم'); ?></th>
                <?php if($tab === 'categories'): ?><th>التصنيف الرئيسي</th><th>المنتجات</th><?php elseif($tab === 'colors'): ?><th>الدرجة</th><th>الرمز</th><th>الأصناف</th><th></th><?php else: ?><th>الرمز</th><th>الترتيب</th><th>الأصناف</th><?php endif; ?>
            </tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr data-attribute-id="<?php echo e($entry->id); ?>">
                        <td><div class="attribute-name"><?php if($tab === 'colors'): ?><?php if (isset($component)) { $__componentOriginal2fa12a4f95ae288df63b99661b1c4b52 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.catalog.color-dot','data' => ['hex' => $entry->display_hex,'label' => $entry->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('catalog.color-dot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hex' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entry->display_hex),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entry->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52)): ?>
<?php $attributes = $__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52; ?>
<?php unset($__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fa12a4f95ae288df63b99661b1c4b52)): ?>
<?php $component = $__componentOriginal2fa12a4f95ae288df63b99661b1c4b52; ?>
<?php unset($__componentOriginal2fa12a4f95ae288df63b99661b1c4b52); ?>
<?php endif; ?><?php endif; ?><strong><?php echo e($entry->name); ?></strong></div><?php if (! ($entry->is_active)): ?><small class="attribute-muted">غير فعال</small><?php endif; ?> <?php if($tab === 'categories' && $entry->description): ?><small class="attribute-description"><?php echo e($entry->description); ?></small><?php endif; ?></td>
                        <?php if($tab === 'categories'): ?>
                            <td><?php echo e($entry->parent?->name ?? 'تصنيف رئيسي'); ?></td><td><?php echo e($entry->products_count); ?></td>
                        <?php elseif($tab === 'colors'): ?>
                            <td><span dir="ltr"><?php echo e($entry->display_hex ?? 'لم تحدد'); ?></span><?php if(!$entry->hex_code && $entry->display_hex): ?><small class="attribute-muted">مقترح من الاسم</small><?php endif; ?></td><td dir="ltr"><?php echo e($entry->code); ?></td><td><?php echo e($entry->variants_count); ?></td><td><button type="button" class="btn btn-outline btn-sm" data-edit-color="<?php echo e(json_encode(['name' => $entry->name, 'hex' => $entry->display_hex, 'url' => route('catalog.attributes.colors.appearance', $entry)])); ?>">ضبط الدرجة</button></td>
                        <?php else: ?>
                            <td dir="ltr"><?php echo e($entry->code); ?></td><td><?php echo e($entry->sort_order); ?></td><td><?php echo e($entry->variants_count); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="<?php echo e(match($tab) { 'colors' => 5, 'sizes' => 4, default => 3 }); ?>" class="attribute-empty"><?php echo e($search !== '' ? 'لا توجد نتائج مطابقة للبحث.' : 'القائمة فارغة حاليًا. أضف أول عنصر من النموذج.'); ?></td></tr>
                <?php endif; ?>
            </tbody></table></div>
            <?php echo $__env->make('catalog.attributes.partials.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </section>
    </div>
</div>
<dialog id="attribute-color-dialog" class="attribute-dialog" aria-labelledby="attribute-dialog-title">
    <form method="post" id="attribute-color-form"><header><h2 id="attribute-dialog-title">ضبط درجة اللون</h2><button type="button" class="btn btn-outline btn-sm" data-close-color aria-label="إغلاق">✕</button></header>
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="attribute-dialog-body"><div class="attribute-errors" data-form-errors role="alert" tabindex="-1" hidden></div><fieldset><?php if (isset($component)) { $__componentOriginala84b9a15176309deae827ab63ec9aff1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala84b9a15176309deae827ab63ec9aff1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.catalog.color-editor','data' => ['id' => 'edit-color','palette' => $palette,'readonlyName' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('catalog.color-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'edit-color','palette' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($palette),'readonly-name' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala84b9a15176309deae827ab63ec9aff1)): ?>
<?php $attributes = $__attributesOriginala84b9a15176309deae827ab63ec9aff1; ?>
<?php unset($__attributesOriginala84b9a15176309deae827ab63ec9aff1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala84b9a15176309deae827ab63ec9aff1)): ?>
<?php $component = $__componentOriginala84b9a15176309deae827ab63ec9aff1; ?>
<?php unset($__componentOriginala84b9a15176309deae827ab63ec9aff1); ?>
<?php endif; ?><p class="attribute-muted">ضبط الدرجة يحدّث العرض البصري للون.</p></fieldset></div>
        <footer><button type="button" class="btn btn-outline" data-close-color>إلغاء</button><button type="submit" class="btn btn-primary">حفظ الدرجة</button></footer>
    </form>
</dialog>
<div id="attribute-feedback" role="status" hidden></div>
<div id="attribute-loading" role="status" hidden>جاري تحديث القائمة...</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="application/json" id="attribute-config"><?php echo json_encode(['indexUrl' => route('catalog.attributes.index'), 'palette' => $palette, 'csrf' => csrf_token()], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
    <script src="<?php echo e(asset('assets/admin/js/pages/catalog/attributes.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/catalog/attributes/index.blade.php ENDPATH**/ ?>