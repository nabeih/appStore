<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="document-pagination">
    <span><?php echo e($paginator->total()); ?> نتيجة · <?php echo e($paginator->currentPage()); ?> / <?php echo e($paginator->lastPage()); ?></span>
    <?php if($paginator->hasPages()): ?>
        <nav aria-label="صفحات النتائج">
            <?php if($paginator->previousPageUrl()): ?><a class="btn btn-outline btn-sm" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">السابق</a><?php endif; ?>
            <?php if($paginator->nextPageUrl()): ?><a class="btn btn-outline btn-sm" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">التالي</a><?php endif; ?>
        </nav>
    <?php endif; ?>
</div>
<?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/components/pagination.blade.php ENDPATH**/ ?>