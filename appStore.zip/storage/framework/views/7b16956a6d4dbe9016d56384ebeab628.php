<?php $__env->startSection('title', 'إدارة المخزون'); ?>
<?php $__env->startSection('content'); ?>
    <div id="screen-inventory" class="screen active">
        <header style="display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;align-items:center;margin-bottom:18px;">
            <div><h1 class="section-title"><i class="fas fa-boxes text-primary"></i> إدارة المخزون</h1><p class="section-subtitle">الكميات الحالية وتكلفة الأصناف حسب الفرع.</p></div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;"><a class="btn btn-primary" href="<?php echo e(route('purchases.invoices.create')); ?>">فاتورة شراء جديدة</a><a class="btn btn-outline" href="<?php echo e(route('purchases.invoices.index')); ?>">سجل فواتير الشراء</a></div>
        </header>
        <div id="purchSubtab-stock" style="display:block;">

            <div class="card">

                <div class="card-header">

                    <h3>
                        <i class="fas fa-boxes text-primary"></i>
                        قائمة المنتجات والكميات الحالية
                    </h3>

                    
                    <div class="search-box">
                        <i class="fas fa-search"></i>

                        <input type="search" id="inventorySearch" placeholder="بحث بالاسم أو الكود..." autocomplete="off">
                    </div>
                    <button type="button" class="btn btn-primary" onclick="openQuickOpeningStockModal()"
                        style="background:linear-gradient(135deg,#4f46e5,#4338ca);font-weight:700;">
                        <i class="fas fa-boxes"></i> إدخال بضاعة أول المدة
                    </button>
                </div>

                
                <div class="d-flex flex-wrap gap-2 mb-3" style="padding:0 16px;align-items:center;">

                    <select id="inventoryQuantityFilter" class="form-select" style="max-width:200px;">
                        <option value="all">كل المنتجات</option>
                        <option value="available">متوفر بالمخزون</option>
                        <option value="empty">الكمية صفر</option>
                    </select>

                    <span id="inventoryVisibleCount" style="font-size:0.85rem;color:var(--gray);">
                    </span>

                </div>

                
                <div class="table-responsive">

                    <table>

                        <thead>
                            <tr>
                                <th>الكود</th>
                                <th>الفرع</th>
                                <th>المنتج</th>
                                <th>التصنيف</th>
                                <th>المقاس</th>
                                <th>اللون</th>
                                <th>متوسط التكلفة</th>
                                <th>سعر البيع</th>
                                <th>الكمية المتاحة</th><?php if($setupChangesEnabled): ?><th>إجراءات</th><?php endif; ?>
                            </tr>
                        </thead>

                        <tbody id="inventoryTableBody">

                            <?php $__empty_1 = true; $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr data-inventory-row data-quantity="<?php echo e($inventory->quantity); ?>">

                                    <td>
                                        <?php echo e($inventory->productVariant?->product?->code ?? '—'); ?>

                                    </td>

                                    <td><?php echo e($inventory->branch?->name ?? '—'); ?></td>

                                    <td>
                                        <?php ($colorImage = $inventory->productVariant?->product?->images->firstWhere('color_id', $inventory->productVariant?->color_id)); ?>
                                        <?php if($colorImage): ?>
                                            <img src="<?php echo e(asset('storage/'.$colorImage->image_path)); ?>" alt="<?php echo e($inventory->productVariant?->product?->name); ?>" width="40" height="40" loading="lazy" style="object-fit:cover;border-radius:6px;margin-inline-end:6px;">
                                        <?php endif; ?>
                                        <?php echo e($inventory->productVariant?->product?->name ?? '—'); ?>

                                    </td>

                                    <td>
                                        <?php echo e($inventory->productVariant?->product?->category?->name ?? '—'); ?>

                                    </td>

                                    <td>
                                        <?php echo e($inventory->productVariant?->size?->name ?? '—'); ?>

                                    </td>

                                    <td>
                                        <?php if (isset($component)) { $__componentOriginal2fa12a4f95ae288df63b99661b1c4b52 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.catalog.color-dot','data' => ['hex' => $inventory->productVariant?->color?->display_hex,'label' => $inventory->productVariant?->color?->name ?? '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('catalog.color-dot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hex' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventory->productVariant?->color?->display_hex),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventory->productVariant?->color?->name ?? '')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52)): ?>
<?php $attributes = $__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52; ?>
<?php unset($__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fa12a4f95ae288df63b99661b1c4b52)): ?>
<?php $component = $__componentOriginal2fa12a4f95ae288df63b99661b1c4b52; ?>
<?php unset($__componentOriginal2fa12a4f95ae288df63b99661b1c4b52); ?>
<?php endif; ?>
                                        <?php echo e($inventory->productVariant?->color?->name ?? '—'); ?>

                                    </td>

                                    <td>
                                        <?php echo e(number_format($inventory->average_cost, 2)); ?>

                                    </td>

                                    <td>
                                        <?php echo e(number_format($inventory->productVariant?->selling_price ?? 0, 2)); ?>

                                    </td>

                                    <td>
                                        <?php echo e($inventory->quantity); ?>

                                    </td>

                                    <?php if($setupChangesEnabled): ?>
                                        <?php echo $__env->make('inventory.setup.partials.actions', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <?php endif; ?>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <tr>
                                    <td colspan="<?php echo e($setupChangesEnabled ? 10 : 9); ?>" class="text-center" style="padding:24px;">
                                        لا توجد بيانات مخزون حاليًا
                                    </td>
                                </tr>

                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

                
                <div style="padding:16px;">
                    <?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $inventories]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($inventories)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
                </div>

            </div>

        </div>


    </div>
    <?php echo $__env->make('inventory.opening-stock.partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if($setupChangesEnabled): ?>
        <?php echo $__env->make('inventory.setup.partials.dialog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/admin/js/pages/inventory.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/inventory/index.blade.php ENDPATH**/ ?>