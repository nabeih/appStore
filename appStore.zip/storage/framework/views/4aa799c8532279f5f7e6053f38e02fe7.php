<?php $__env->startSection('title', 'البضاعة الافتتاحية'); ?>
<?php $__env->startSection('content'); ?>
<div class="screen active os-page">
    <header class="os-page-title"><div><h1 class="section-title">البضاعة الافتتاحية</h1><p class="section-subtitle">بضاعتك الموجودة، بدون فاتورة شراء.</p></div><button type="button" class="btn btn-primary" onclick="openQuickOpeningStockModal()">+ إدخال بضاعة</button></header>
    <details class="card document-filters" <?php if(array_filter($filters)): ?> open <?php endif; ?>>
        <summary><span><i class="fas fa-sliders-h" aria-hidden="true"></i> تصفية المستندات</span><small>الفرع والتاريخ</small></summary>
        <form method="get" class="os-filter-form document-filter-grid">
            <label class="filter-wide">الفرع<select name="branch_id"><option value="">كل الفروع</option><?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($branch->id); ?>" <?php if(($filters['branch_id'] ?? '') == $branch->id): echo 'selected'; endif; ?>><?php echo e($branch->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label>من تاريخ<input type="date" name="from" value="<?php echo e($filters['from'] ?? ''); ?>"></label>
            <label>إلى تاريخ<input type="date" name="to" value="<?php echo e($filters['to'] ?? ''); ?>"></label>
            <div class="document-filter-actions"><button class="btn btn-primary" type="submit">تطبيق</button><a class="btn btn-outline" href="<?php echo e(route('inventory.opening-stock.index')); ?>">مسح</a></div>
            <?php if($errors->any()): ?><p role="alert"><?php echo e($errors->first()); ?></p><?php endif; ?>
        </form>
    </details>
    <section class="card document-record-list"><div class="table-responsive"><table class="mobile-records" role="table" aria-label="مستندات البضاعة الافتتاحية"><thead><tr><th>رقم المستند</th><th>تاريخ الرصيد</th><th>الفرع</th><th>الأصناف</th><th>القطع</th><th>قيمة البضاعة ₪</th><th>الحالة</th><th></th></tr></thead><tbody>
        <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="record-primary" data-label="المستند"><a href="<?php echo e(route('inventory.opening-stock.show', $entry)); ?>"><?php echo e($entry->number); ?></a></td>
                <td data-label="تاريخ الرصيد"><?php echo e($entry->opening_date?->format('Y-m-d') ?? '—'); ?></td>
                <td data-label="الفرع"><?php echo e($entry->branch->name); ?></td>
                <td data-label="الأصناف"><?php echo e($entry->items_count); ?></td>
                <td data-label="القطع"><?php echo e($entry->total_quantity); ?></td>
                <td class="record-amount" data-label="قيمة البضاعة ₪"><?php echo e($entry->total_cost); ?></td>
                <td class="record-status"><span class="badge <?php echo e($entry->status === 'cancelled' ? 'danger' : 'success'); ?>"><?php echo e(match ($entry->status) { 'approved' => 'معتمد', 'cancelled' => 'ملغى أثناء التجهيز', default => 'مسودة' }); ?></span></td>
                <td class="record-action"><a class="btn btn-outline btn-sm" href="<?php echo e(route('inventory.opening-stock.show', $entry)); ?>">عرض المستند</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr class="record-empty"><td colspan="8" class="empty"><strong>لا توجد بضاعة افتتاحية بعد</strong><p>ابدأ بإدخال البضاعة الموجودة لديك.</p><button type="button" class="btn btn-primary" onclick="openQuickOpeningStockModal()">إدخال بضاعة</button></td></tr>
        <?php endif; ?>
    </tbody></table></div><?php if (isset($component)) { $__componentOriginal41032d87daf360242eb88dbda6c75ed1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal41032d87daf360242eb88dbda6c75ed1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pagination','data' => ['paginator' => $entries]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($entries)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $attributes = $__attributesOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__attributesOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal41032d87daf360242eb88dbda6c75ed1)): ?>
<?php $component = $__componentOriginal41032d87daf360242eb88dbda6c75ed1; ?>
<?php unset($__componentOriginal41032d87daf360242eb88dbda6c75ed1); ?>
<?php endif; ?></section>
</div>
<?php echo $__env->make('inventory.opening-stock.partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/inventory/opening-stock/index.blade.php ENDPATH**/ ?>