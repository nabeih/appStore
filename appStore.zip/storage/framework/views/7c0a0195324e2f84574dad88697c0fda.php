<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['id', 'palette', 'nameValue' => '', 'hexValue' => '', 'readonlyName' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['id', 'palette', 'nameValue' => '', 'hexValue' => '', 'readonlyName' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php ($hexValue = is_string($hexValue) ? $hexValue : ''); ?>
<?php ($nameValue = is_string($nameValue) ? $nameValue : ''); ?>
<div data-color-editor>
    <label for="<?php echo e($id); ?>-name">اسم اللون</label>
    <input id="<?php echo e($id); ?>-name" name="name" value="<?php echo e($nameValue); ?>" maxlength="100" required data-color-name <?php if($readonlyName): echo 'readonly'; endif; ?> placeholder="مثال: أحمر، كحلي، بيج">
    <div class="attribute-color-controls">
        <label class="attribute-picker-label" for="<?php echo e($id); ?>-picker">اختر الدرجة
            <input id="<?php echo e($id); ?>-picker" type="color" value="<?php echo e(preg_match('/^#[0-9a-f]{6}$/i', $hexValue) ? $hexValue : '#808080'); ?>" data-color-picker>
        </label>
        <label class="attribute-hex-label" for="<?php echo e($id); ?>-hex">درجة اللون
            <input id="<?php echo e($id); ?>-hex" name="hex_code" value="<?php echo e($hexValue); ?>" dir="ltr" maxlength="7" pattern="#[0-9a-fA-F]{6}" placeholder="#2563EB" autocomplete="off" spellcheck="false" required data-color-hex>
        </label>
        <span class="attribute-color-preview" data-color-preview aria-label="معاينة اللون"></span>
    </div>
    <p class="attribute-color-message" data-color-message aria-live="polite">اكتب اسم لون شائع لاقتراح درجته، أو اختر الدرجة بنفسك.</p>
    <button type="button" class="btn btn-outline btn-sm" data-color-suggest>اقتراح الدرجة من الاسم</button>
    <div class="attribute-palette" aria-label="ألوان جاهزة">
        <?php $__currentLoopData = $palette; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" data-color-preset="<?php echo e($preset['hex']); ?>" data-color-label="<?php echo e($preset['name']); ?>" title="<?php echo e($preset['name']); ?>" aria-label="اختيار <?php echo e($preset['name']); ?>"><?php if (isset($component)) { $__componentOriginal2fa12a4f95ae288df63b99661b1c4b52 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.catalog.color-dot','data' => ['hex' => $preset['hex'],'label' => $preset['name']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('catalog.color-dot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hex' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($preset['hex']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($preset['name'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52)): ?>
<?php $attributes = $__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52; ?>
<?php unset($__attributesOriginal2fa12a4f95ae288df63b99661b1c4b52); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2fa12a4f95ae288df63b99661b1c4b52)): ?>
<?php $component = $__componentOriginal2fa12a4f95ae288df63b99661b1c4b52; ?>
<?php unset($__componentOriginal2fa12a4f95ae288df63b99661b1c4b52); ?>
<?php endif; ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/components/catalog/color-editor.blade.php ENDPATH**/ ?>