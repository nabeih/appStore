<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <i class="fas fa-tshirt"></i><span>متجر الأناقة</span>
    </div>
    <div class="sidebar-user">
        <div class="user-avatar" id="userAvatar"><?php echo e(mb_substr(auth()->user()->name, 0, 1)); ?></div>
        <div class="sidebar-user-info">
            <h6 id="userName"><?php echo e(auth()->user()->name); ?></h6>
            <small id="userRole"><?php echo e(auth()->user()->username); ?></small>
        </div>
    </div>
    <nav class="sidebar-nav" id="sidebarNav">

        <div class="nav-title">الرئيسية</div>

        <a href="<?php echo e(route('dashboard.index')); ?>"
            class="nav-item <?php echo e(request()->routeIs('dashboard.*') ? 'active' : ''); ?>"
            style="text-decoration:none;color:inherit;">
            <i class="fas fa-chart-pie"></i>
            <span>لوحة التحكم</span>
        </a>

        <div class="nav-title">العمليات</div>

        <a href="<?php echo e(route('inventory.index')); ?>"
            class="nav-item <?php echo e(request()->routeIs('inventory.index', 'inventory.update') ? 'active' : ''); ?>"
            style="text-decoration:none;color:inherit;">
            <i class="fas fa-dolly-flatbed"></i>
            <span>إدارة المخزون</span>
        </a>

        <a href="<?php echo e(route('inventory.opening-stock.index')); ?>" class="nav-item <?php echo e(request()->routeIs('inventory.opening-stock.*') ? 'active' : ''); ?>" style="text-decoration:none;color:inherit;">
            <i class="fas fa-box-open"></i><span>البضاعة الافتتاحية</span>
        </a>
        <a href="<?php echo e(route('catalog.attributes.index')); ?>" class="nav-item <?php echo e(request()->routeIs('catalog.attributes.*') ? 'active' : ''); ?>" style="text-decoration:none;color:inherit;">
            <i class="fas fa-tags"></i><span>التصنيفات والسمات</span>
        </a>
        <a href="<?php echo e(route('suppliers.index')); ?>" class="nav-item <?php echo e(request()->routeIs('suppliers.*') ? 'active' : ''); ?>" style="text-decoration:none;color:inherit;"><i class="fas fa-truck"></i><span>الموردون</span></a>
        <a href="<?php echo e(route('purchases.invoices.index')); ?>" class="nav-item <?php echo e(request()->routeIs('purchases.*') ? 'active' : ''); ?>" style="text-decoration:none;color:inherit;"><i class="fas fa-file-invoice"></i><span>فواتير الشراء</span></a>
    </nav>

</aside><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>