<form method="post" action="<?php echo e(route('catalog.attributes.categories.store')); ?>" data-attribute-form="categories" class="attribute-form">
    <?php echo csrf_field(); ?>
    <h2>إضافة تصنيف</h2>
    <div class="attribute-errors" data-form-errors role="alert" tabindex="-1" hidden></div>
    <fieldset>
        <label for="category-name">اسم التصنيف</label><input id="category-name" name="name" maxlength="100" value="<?php echo e(old('name')); ?>" placeholder="مثال: ملابس أطفال" required>
        <label for="category-parent">التصنيف الرئيسي (اختياري)</label>
        <select id="category-parent" name="parent_id"><option value="">تصنيف رئيسي مستقل</option><?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($parent->id); ?>" <?php if(old('parent_id') == $parent->id): echo 'selected'; endif; ?>><?php echo e($parent->name); ?><?php if($parent->parent): ?> — <?php echo e($parent->parent->name); ?><?php endif; ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <label for="category-description">وصف (اختياري)</label><textarea id="category-description" name="description" rows="3" maxlength="2000" placeholder="وصف يساعدك بتنظيم المنتجات"><?php echo e(old('description')); ?></textarea>
        <button type="submit" class="btn btn-primary attribute-submit">إضافة التصنيف</button>
    </fieldset>
</form><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/catalog/attributes/partials/category-form.blade.php ENDPATH**/ ?>