<!-- ============ Modal: إدخال سريع لبضاعة أول المدة واستيراد ملفات ============ -->
<div class="modal-overlay" id="quickOpeningStockModal">
    <div class="modal-box" style="max-width:980px;width:95vw;">
        <div class="modal-header">
            <div>
                <h5 style="margin:0;font-weight:800;display:flex;align-items:center;gap:8px;">
                    <i class="fas fa-boxes text-primary"></i> إدخال بضاعة أول المدة السريعة (الرصيد الافتتاحي)
                </h5>
                <small style="color:var(--gray);font-size:0.78rem;">أدخل البضاعة المتوفرة لديك حالياً في المحل لتجهيز
                    المخزون ونظام الكاشير فوراً</small>
            </div>
            <button class="modal-close" onclick="closeOpeningStockModal()"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body" style="padding:16px;">
            <div id="openingStockErrors" role="alert" style="display:none;color:#b91c1c;margin-bottom:12px;"></div>
            <div style="margin-bottom:12px"><label>الفرع: <select id="openingStockBranch"
                        class="quick-stock-select"><?php $__currentLoopData = $openingStockBranches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select></label></div>
            <!-- أدوات الاستيراد والتحميل -->
            <div
                style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:12px 14px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
                <div style="font-size:0.84rem;color:#334155;">
                    <i class="fas fa-file-csv text-success" style="font-size:1.1rem;margin-left:4px;"></i>
                    <strong>استيراد جاهز من Excel أو CSV:</strong> يمكنك تحميل نموذج فارغ وملئه ثم استيراده هنا بنقرة
                    واحدة.
                </div>
                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    <button type="button" class="btn btn-outline btn-sm" onclick="downloadOpeningStockTemplate()"
                        title="تحميل ملف إكسل CSV فارغ مع أمثلة">
                        <i class="fas fa-download"></i> تحميل النموذج الفارغ (Excel / CSV)
                    </button>
                    <label class="btn btn-outline btn-sm"
                        style="margin:0;cursor:pointer;border-color:#10b981;color:#10b981;background:#f0fdf4;"
                        title="رفع واستيراد ملف CSV">
                        <i class="fas fa-upload"></i> استيراد ملف CSV
                        <input type="file" id="openingStockCsvInput" accept=".csv,text/csv" style="display:none;"
                            onchange="handleOpeningStockCsvUpload(event)">
                    </label>
                </div>
            </div>
            <div class="card" style="margin-bottom:16px;padding:16px;">
                <h6 style="font-weight:800;margin-bottom:12px;">
                    إضافة منتج بعدة ألوان ومقاسات
                </h6>

                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
                    <div>
                        <label>اسم المنتج</label>
                        <input id="matrixProductName" class="quick-stock-input" placeholder="مثال: قميص ولادي">
                    </div>

                    <div>
                        <label>كود المنتج (اختياري)</label>
                        <input id="matrixProductCode" class="quick-stock-input" placeholder="مثال: B2">
                    </div>

                    <div>
                        <label>التصنيف</label>
                        <select id="matrixCategory" class="quick-stock-select"></select>
                    </div>

                    <div>
                        <label>الألوان (اختيار متعدد)</label>
                        <select id="matrixColors" class="quick-stock-select" multiple size="4"></select>
                    </div>

                    <div>
                        <label>المقاسات (اختيار متعدد)</label>
                        <select id="matrixSizes" class="quick-stock-select" multiple size="4"></select>
                    </div>
                </div>

                <div style="margin-top:14px;">
                    <button type="button" class="btn btn-primary" onclick="generateOpeningStockVariants()">
                        توليد تركيبات الألوان والمقاسات
                    </button>
                </div>
            </div>

            <!-- جدول الإدخال السريع -->
            <div class="table-responsive"
                style="max-height:360px;overflow-y:auto;border:1px solid #cbd5e1;border-radius:10px;">
                <table class="quick-stock-table"
                    style="width:100%;border-collapse:collapse;margin:0;font-size:0.83rem;">
                    <thead
                        style="position:sticky;top:0;background:#f1f5f9;z-index:2;box-shadow:0 1px 2px rgba(0,0,0,0.05);">
                        <tr>
                            <th style="padding:8px 6px;text-align:center;width:35px;">#</th>
                            <th style="padding:8px 8px;text-align:right;min-width:170px;">اسم المنتج *</th>
                            <th style="padding:8px 8px;text-align:right;min-width:130px;">التصنيف *</th>
                            <th style="padding:8px 8px;text-align:center;min-width:85px;">المقاس</th>
                            <th style="padding:8px 8px;text-align:center;min-width:85px;">اللون</th>
                            <th style="padding:8px 8px;text-align:center;min-width:75px;">الكمية *</th>
                            <th style="padding:8px 8px;text-align:center;min-width:95px;">سعر التكلفة ₪ *</th>
                            <th style="padding:8px 8px;text-align:center;min-width:95px;">سعر البيع ₪ *</th>
                            <th style="padding:8px 8px;text-align:center;min-width:110px;">صورة اللون</th>
                            <th style="padding:8px 6px;text-align:center;width:40px;">إجراء</th>
                        </tr>
                    </thead>
                    <tbody id="quickOpeningStockTableBody">
                        <!-- صفوف الإدخال الديناميكية -->
                    </tbody>
                </table>
            </div>

            <div
                style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;flex-wrap:wrap;gap:10px;">
                <button type="button" class="btn btn-outline btn-sm" onclick="addQuickOpeningStockRow()"
                    style="border-color:#4f46e5;color:#4f46e5;font-weight:700;">
                    <i class="fas fa-plus"></i> إضافة سطر جديد
                </button>
                <div id="quickStockSummary" style="font-size:0.85rem;color:#475569;font-weight:700;">
                    عدد الأسطر: <span id="quickStockRowCount" style="color:var(--primary);">0</span> |
                    إجمالي القطع: <span id="quickStockTotalQty" style="color:var(--success);">0</span> |
                    إجمالي رأس المال: <span id="quickStockTotalCost" style="color:#0f172a;">₪0.00</span>
                </div>
            </div>

            <div class="modal-actions"
                style="margin-top:16px;border-top:1px solid #e2e8f0;padding-top:14px;display:flex;justify-content:flex-end;gap:10px;">
                <button type="button" class="btn btn-outline" onclick="closeOpeningStockModal()">إلغاء</button>
                <button type="button" class="btn btn-primary" onclick="submitOpeningStock()"
                    style="background:linear-gradient(135deg,#4f46e5,#4338ca);font-weight:700;">
                    <i class="fas fa-check-double"></i> حفظ الرصيد الافتتاحي
                </button>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\laravel\Laravel projects\appStore\resources\views/inventory/partials/opening-stock-modal.blade.php ENDPATH**/ ?>