<x-pagination :paginator="$entries" />
